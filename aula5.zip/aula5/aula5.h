/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   aula5.h
 * Author: Pang
 *
 * Created on 13 September 2019, 13:30
 */

#ifndef AULA5_H
#define AULA5_H

#ifdef __cplusplus
extern "C" {
#endif

    /*
     * Funcao que calcula o fatorial
     * Argumento: n numero cujo fatorial vai ser calculado
     * Retorna: um int com o fatorial
     */
    int fato_i(int n);
    
    /*
     * Funcao que calcula o fatorial
     * Argumento: n numero cujo fatorial vai ser calculado
     * Retorna: um long com o fatorial
     */
    long fato_l(int n);
    
    /*
     * Funcao que calcula o fatorial
     * Argumento: n numero cujo fatorial vai ser calculado
     * Retorna: um int com o fatorial
     */
    long long fato_ll(int n);
    
    /*
     * Funcao que calcula o n-esimo elemento da serie de Fibonacci
     * Argumento: n numero do elemento
     * Retorna: um int 
     */
    int fibo(int n);
    
    /*
     *Funcao que reverte um texto
     * Argumento: texto ponteiro para o primeiro caracter da string C
     * Retorna: o texto invertido
     */
    char* reverte(char *texto);
    
    /*
     * Funcao que le as notas p1 e p2 de um aluno
     * Argumentos: pp1 e pp2 ponteiros para floats onde serao colocadas as notas
     * Retorna: nada, o retorno eh feito nos argumentos
     */
    void le_notas(float *pp1, float *pp2);
    
    /*
     * Função que imprime a media ponderada a partir das notas p1 e p1
     * Argumentos: p1 e p2 sao floats com as notas
     * Retorna: nada, só imprime
     */
    void imprime_media(float p1, float p2);

#ifdef __cplusplus
}
#endif

#endif /* AULA5_H */

