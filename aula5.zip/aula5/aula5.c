/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "aula5.h"
#include <stdio.h>
#include <string.h>

int fato_i(int n) {
    int i;
    int res = 1;
    // complete o codigo abaixo
    for (i = 2 ; i <= n; i++ ) {
        res *= i;
    }
    return res;
}

long fato_l(int n) {
    int i;
    long res = 1L;
    // complete o codigo abaixo
    for (i = 2 ; i <= n; i++ ) {
        res *= i;
    }
    return res;
}

long long fato_ll(int n) {
    int i;
    long long res = 1LL;
    // complete o codigo abaixo
    for (i = 2 ; i <= n; i++ ) {
        res *= i;
    }
    return res;
}

int fibo(int n) {
    if (n == 1)
        return 0;
    if (n == 2)
        return 1;
    int anterior = 0;
    int atual = 1;
    int res;
    int i;
    // complete o codigo abaixo
    for (i = 3; i <= n; i++) {
        res = anterior + atual;
        anterior = atual;
        atual = res;
    }
    return res;
}

/*
 * copia do ultimo para o primeiro
 */
char* reverte(char *texto) {
    int comprimento = strlen(texto);
    static char res[80];
    int i;
    i = 0;
    while (i < comprimento){
        res[i] = texto[comprimento -1 - i];
        i++;
    }
    res[i] = '\0';
    return res;
}

void le_notas(float *pp1, float *pp2) {
    printf("Nota p1 = ");
    scanf("%f", pp1);
    printf("Nota p2 = ");
    scanf("%f", pp2);
}

void imprime_media(float p1, float p2) {
    printf("A media do aluno eh: %4.1f\n", (p1 + 2 * p2) / 3);
}