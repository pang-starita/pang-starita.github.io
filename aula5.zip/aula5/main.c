/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Pang
 *
 * Created on 13 September 2019, 13:29
 */

#include "aula5.h"
#include <stdio.h>
#include <stdlib.h>

/*
 * Testa as funcoes de aula5.c
 */
int main(int argc, char** argv) {
    // teste das funcoes fatoriais
    int ns[7] = {3, 5, 9, 13, 18, 22, 25};
    int i;
    for (i = 0; i < 7; i++) {
        printf("O fatorial de %d eh:\n int = %d\n long = %ld\n long long = %lld\n",
                ns[i], fato_i(ns[i]), fato_l(ns[i]), fato_ll(ns[i]));
    }
    // teste do Fibonacci
    for (i = 0; i < 7; i++) {
        printf("Fibo de (%d) = %d\n", ns[i], fibo(ns[i]));
    }
    // teste da reversao de texto
    char *texto = "texto de teste";
    printf("O texto a ser invertido eh '%s'.\n", texto);
    char *invertido = reverte(texto);
    printf("O texto invertido eh '%s'.\n", invertido);
    // teste para le notas e imprimir media
    float p1, p2;
    le_notas(&p1, &p2);
    imprime_media(p1, p2);
    return (EXIT_SUCCESS);
}

