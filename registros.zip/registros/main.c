/*
 * Este programa ilustra o uso de registros em C.
 */

/* 
 * File:   main.c
 * Author: Paulino Ng <paulino.ng at santarita.br>
 *
 * Created on 22 de Novembro de 2019, 19:45
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
  // registros em C sao chamados de estruturas
  struct _aluno {
    char nome[80];
    long matr;
  } alu1;
  // leitura do nome
  printf("Fornessa o nome do aluno: ");
  fgets(alu1.nome, 80, stdin);
  alu1.nome[strlen(alu1.nome)-1] = '\0'; // para retirar o \n
  // leitura da matricula
  printf("Fornessa o numero de matricula de %s: ", alu1.nome);
  scanf("%ld", &(alu1.matr));
  printf("Aluno: %s\tMatricula: %ld\n", alu1.nome, alu1.matr);
  // alocando outro aluno
  struct _aluno alu2;
  printf("Fornessa o nome do aluno: ");
  fgets(alu2.nome, 80, stdin);   // nao esperou pelo nome do alu2, por que? corrija
  alu2.nome[strlen(alu2.nome)-1] = '\0'; // para retirar o \n
  // leitura da matricula
  printf("Fornessa o numero de matricula de %s: ", alu2.nome);
  scanf("%ld", &(alu2.matr));
  printf("Aluno: %s\tMatricula: %ld\n", alu2.nome, alu2.matr);
  // alocacao dinamica de uma struct
  struct _aluno *pAlu = (struct _aluno*) malloc(sizeof(struct _aluno));
  printf("Fornessa o nome do aluno: ");
  fgets(pAlu->nome, 80, stdin);   // nao esperou pelo nome do alu2, por que? corrija
  pAlu->nome[strlen(pAlu->nome)-1] = '\0'; // para retirar o \n
  // leitura da matricula
  printf("Fornessa o numero de matricula de %s: ", pAlu->nome);
  scanf("%ld", &(pAlu->matr));
  printf("Aluno: %s\tMatricula: %ld\n", pAlu->nome, pAlu->matr);  
  return (EXIT_SUCCESS);
}

