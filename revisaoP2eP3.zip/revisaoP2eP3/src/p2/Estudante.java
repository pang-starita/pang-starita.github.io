
package p2;

public class Estudante extends Pessoa{
    String faculdade;
    String formacao;
    int etapa;
    public void avanca() {
        etapa = etapa + 1;
    }
}
