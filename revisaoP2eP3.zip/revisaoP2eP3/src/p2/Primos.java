
package p2;

public class Primos {
    public static void main(String[] args) {
        int[] primos = {2,3,5,7,11,13,17,19,23};
        for (int primo: primos) {
            System.out.println("Primo: " + primo);
        }
    }
}
