
package p2;

import java.util.Scanner;

public class TestaPessoa {
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa();
        Pessoa p2 = new Pessoa();
        Scanner sc = new Scanner(System.in);
        System.out.print("Fornessa o nome de p1: ");
        p1.nome = sc.nextLine();  // mais de uma string next() so le 1
        System.out.println("Fornessa a idade de "+p1.nome+": ");
        p1.idade = sc.nextInt();
        sc.nextLine();  // necessario para limpar o restante da linha
        System.out.print("Fornessa o nome de p2: ");
        p2.nome = sc.nextLine();  // mais de uma string next() so le 1
        System.out.println("Fornessa a idade de "+p2.nome+": ");
        p2.idade = sc.nextInt();
        sc.nextLine();  // necessario para limpar o restante da linha
        System.out.println("Dados de p1:");
        System.out.println("Nome: " + p1.nome);
        System.out.println("Idade: " + p1.idade);
        System.out.println("Dados de p2:");
        System.out.println("Nome: " + p2.nome);
        System.out.println("Idade: " + p2.idade);
    }
}
