/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

import java.util.Scanner;

/**
 *
 * @author labb
 */
public class TestaEstudante {
    public static void main(String[] args) {
        Estudante e = new Estudante();
        Scanner sc = new Scanner(System.in);
        System.out.print("Nome do estudante: ");
        e.nome = sc.nextLine();
        System.out.print("Idade de " + e.nome + ": ");
        e.idade = sc.nextInt();
        sc.nextLine();
        System.out.print("Faculdade de " + e.nome + ": ");
        e.faculdade = sc.nextLine();
        System.out.print("Formacao pretendida de " + e.nome + ": ");
        e.formacao = sc.nextLine();
        System.out.print("Etapa atual de " + e.nome + ": ");
        e.etapa = sc.nextInt();
        sc.nextLine();
        System.out.println("Dados de " + e.nome);
        System.out.println("Idade: " + e.idade);
        System.out.println("Faculdade: " + e.faculdade);
        System.out.println("Formacao: " + e.formacao);
        System.out.println("Etapa: " + e.etapa);
        System.out.println("Avancando uma etapa para " + e.nome);
        e.avanca();
        System.out.println("Dados de " + e.nome);
        System.out.println("Idade: " + e.idade);
        System.out.println("Faculdade: " + e.faculdade);
        System.out.println("Formacao: " + e.formacao);
        System.out.println("Etapa: " + e.etapa);        
    }
}
