/* 
 * File:   main.c
 * Author: paulino.ng
 *
 * Created on 26 de Setembro de 2019, 20:20
 */

#include "fibo.h"
#include <stdio.h>
#include <stdlib.h>

/*
 * Programa para testar as duas funções. Este teste alem de verificar se
 * as funcoes estao corretas par apequenos valores de n, procura mostrar
 * que para valores maiores, as funcoes crescem muito rapido e a versao
 * com int de retorno comeca a calcular valores errados. Obs.: para n = 128,
 * ambas funcoes calculam valores errados.
 */
int main() {
  int tests[] = {2,4,6,8,16,32,40,48,56,64,128,0};
  int i;
  for (i=0; tests[i] != 0; i++)
    printf("fibo_i(%3d) = %12u\tfibo_l(%3d) = %22lu\n", tests[i],
            fibo_i(tests[i]), tests[i], fibo_l(tests[i]));
  printf("Ciao!\n");
  return (EXIT_SUCCESS);
}

