/*
 * Este código tem seus direitos reservados para a UniSantaRita.
 */

unsigned int fibo_i(int n) {
  if (n == 0) return 0;
  if (n == 1) return 1;
  unsigned int ant = 0, atu = 1;
  int i;
  for (i = 2; i < n; i++) {
    int aux = ant;
    ant = atu;
    atu = aux + atu;
  }
  return atu;
}

unsigned long fibo_l(int n) {
  if (n == 0) return 0L;
  if (n == 1) return 1L;
  unsigned long ant = 0L, atu = 1L;
  int i;
  for (i = 2; i < n; i++) {
    unsigned long aux = ant;
    ant = atu;
    atu = aux + atu;
  }
  return atu;  
}
