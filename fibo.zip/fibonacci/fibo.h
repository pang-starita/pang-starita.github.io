/*
 * Este código tem seus direitos reservados para a UniSantaRita.
 */

/* 
 * File:   fibo.h
 * Author: Paulino Ng <paulino.ng at santarita.br>
 *
 * Created on 26 de Setembro de 2019, 21:19
 */

#ifndef FIBO_H
#define FIBO_H

#ifdef __cplusplus
extern "C" {
#endif

  /*
   * fibo_i - calcula de modo iterativo o n-esimo elemento da sequencia de
   * Fibonacci
   * n - ordem do elemento
   * retorna n-esimo elem da seq de Fibonacci
   */
  unsigned int fibo_i(int n);
  
  /*
   * fibo_i - calcula de modo iterativo o n-esimo elemento da sequencia de
   * Fibonacci
   * n - ordem do elemento
   * retorna n-esimo elem da seq de Fibonacci em 64 bits
   */
  unsigned long fibo_l(int n);


#ifdef __cplusplus
}
#endif

#endif /* FIBO_H */

